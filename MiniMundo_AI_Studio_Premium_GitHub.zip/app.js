const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];
const STORE = "minimundo_premium_projects_v1";
let projects = loadProjects();
let currentStory = "";

function loadProjects(){ try{return JSON.parse(localStorage.getItem(STORE)||"[]")}catch{return []} }
function persist(){ localStorage.setItem(STORE, JSON.stringify(projects)); }
function toast(message){
  const el=$("#toast"); if(!el) return;
  el.textContent=message; el.classList.add("show");
  clearTimeout(toast.timer); toast.timer=setTimeout(()=>el.classList.remove("show"),2600);
}
function navigate(page){
  const target=$("#page-"+page); if(!target) return;
  $$(".page").forEach(p=>p.classList.remove("active"));
  target.classList.add("active");
  $$(".nav-link[data-page]").forEach(b=>b.classList.toggle("active",b.dataset.page===page));
  $("#pageName").textContent=({inicio:"Inicio",crear:"Crear proyecto",personajes:"Personajes",biblioteca:"Mi biblioteca",ajustes:"Ajustes"})[page]||page;
  $("#sidebar").classList.remove("open");
  location.hash=page;
  window.scrollTo({top:0,behavior:"smooth"});
}
document.addEventListener("click",e=>{
  const nav=e.target.closest("[data-page]");
  if(nav) navigate(nav.dataset.page);
});
$("#mobileMenu").addEventListener("click",()=>$("#sidebar").classList.toggle("open"));
window.addEventListener("hashchange",()=>{const p=location.hash.slice(1);if($("#page-"+p))navigate(p)});
if(location.hash && $("#page-"+location.hash.slice(1))) navigate(location.hash.slice(1));

function selectedCast(){
  return $$('input[name="cast"]:checked').map(i=>i.value);
}
const names={leo:"Leo",coco:"Coco",dumbo:"Dumbo"};
const emojis={leo:"🦁",coco:"🐵",dumbo:"🐘"};
$$('input[name="cast"]').forEach(input=>input.addEventListener("change",()=>{
  input.closest(".cast-option").classList.toggle("selected",input.checked);
  $("#castSummary").textContent=selectedCast().length+" seleccionados";
}));
$("#idea").addEventListener("input",e=>$("#charCount").textContent=e.target.value.length+" / 700");
$("#format").addEventListener("change",e=>{
  const labels={"16:9":"16:9 · Horizontal","9:16":"9:16 · Vertical","1:1":"1:1 · Cuadrado"};
  $("#formatSummary").textContent=labels[e.target.value];
});

function makeStory(idea, cast, duration){
  const chosen=cast.map(k=>names[k]);
  const lead=chosen[0]||"Leo";
  const second=chosen[1]||"Coco";
  const third=chosen[2]||"Dumbo";
  const title=idea.trim().length>55 ? idea.trim().slice(0,52)+"…" : idea.trim();
  const intro=idea.trim()||"una aventura misteriosa en el bosque";
  const lines=[
`MINIMUNDO AI STUDIO · GUION DE AVENTURA`,
`Título: ${title||"Una aventura inolvidable"}`,
`Duración objetivo: ${duration} minuto(s)`,
`Personajes: ${chosen.join(", ")||"Leo, Coco y Dumbo"}`,
``,
`ESCENA 1 · UNA IDEA INESPERADA`,
`NARRADOR: En un rincón mágico de MiniMundo, ${chosen.join(", ")} se preparaban para un día tranquilo… hasta que apareció una sorpresa.`,
`${lead.toUpperCase()}: ¡Amigos! ¡Creo que hoy nos espera una gran aventura!`,
`${second.toUpperCase()}: ¿Una aventura? ¡Espero que tenga emoción… y algo para comer!`,
`${third.toUpperCase()}: ¡Yo estoy preparado! ¿Qué tenemos que hacer?`,
``,
`ESCENA 2 · EL MISTERIO`,
`NARRADOR: Todo comenzó cuando descubrieron ${intro}. Los tres amigos se miraron sorprendidos.`,
`${lead.toUpperCase()}: Lo primero es mantener la calma y pensar un plan.`,
`${second.toUpperCase()}: ¡Tengo una idea! Bueno… casi siempre tengo una idea.`,
`${third.toUpperCase()}: Si vamos juntos, seguro que lo conseguimos.`,
``,
`ESCENA 3 · TRABAJO EN EQUIPO`,
`NARRADOR: El camino no fue fácil. Tuvieron que escucharse, ayudarse y confiar unos en otros.`,
`${second.toUpperCase()}: ¡Mirad! ¡Creo que he encontrado una pista!`,
`${lead.toUpperCase()}: ¡Buen trabajo, Coco! Sigamos juntos.`,
`${third.toUpperCase()}: ¡La amistad es nuestra mejor herramienta!`,
``,
`ESCENA 4 · UN FINAL ESPECIAL`,
`NARRADOR: Gracias a sus ideas y al trabajo en equipo, nuestros amigos encontraron una solución. No habían descubierto solo algo sorprendente: habían aprendido que cada uno tenía algo especial que aportar.`,
`${lead.toUpperCase()}: ¡Lo hemos conseguido!`,
`${second.toUpperCase()}: ¡Y sin perder el sentido del humor!`,
`${third.toUpperCase()}: ¡La próxima aventura será todavía mejor!`,
``,
`NARRADOR: Y así terminó otro día inolvidable en MiniMundo. Porque cuando Leo, Coco y Dumbo están juntos, cualquier pequeño comienzo puede convertirse en una gran aventura.`,
``,
`FIN · MINI MUNDO`
  ];
  return {title:title||"Una aventura inolvidable",text:lines.join("\n")};
}
$("#createStory").addEventListener("click",()=>{
  const cast=selectedCast();
  if(!cast.length){toast("Selecciona al menos un protagonista.");return;}
  const idea=$("#idea").value.trim();
  if(!idea){toast("Escribe una idea para tu aventura.");$("#idea").focus();return;}
  const result=makeStory(idea,cast,$("#duration").value);
  currentStory=result.text;
  $("#storyTitle").textContent=result.title;
  $("#storyText").textContent=result.text;
  $("#storyResult").classList.remove("hidden");
  $("#storyResult").scrollIntoView({behavior:"smooth",block:"start"});
  toast("¡Tu borrador de historia está listo!");
});
$("#saveStory").addEventListener("click",()=>{
  if(!currentStory){toast("Primero crea una historia.");return;}
  const project={
    id:Date.now(),title:$("#storyTitle").textContent,content:currentStory,
    idea:$("#idea").value,cast:selectedCast(),duration:$("#duration").value,
    format:$("#format").value,created:new Date().toISOString()
  };
  projects.unshift(project);persist();renderProjects();toast("Proyecto guardado en este dispositivo.");
});
$("#copyStory").addEventListener("click",async()=>{
  if(!currentStory)return;
  try{await navigator.clipboard.writeText(currentStory);toast("Guion copiado.");}
  catch{toast("Tu navegador no permite copiar automáticamente.");}
});
$("#listenStory").addEventListener("click",()=>{
  if(!currentStory)return;
  if(!("speechSynthesis" in window)){toast("La voz no está disponible en este navegador.");return;}
  speechSynthesis.cancel();
  const utterance=new SpeechSynthesisUtterance(currentStory);
  utterance.lang=$("#voice").value;utterance.rate=.94;
  const voice=speechSynthesis.getVoices().find(v=>v.lang.toLowerCase().startsWith($("#voice").value.slice(0,2)));
  if(voice)utterance.voice=voice;
  utterance.onstart=()=>$("#voiceStatus").textContent="Reproduciendo narración de prueba…";
  utterance.onend=()=>$("#voiceStatus").textContent="Narración finalizada.";
  speechSynthesis.speak(utterance);
});
$("#stopVoice").addEventListener("click",()=>{if("speechSynthesis"in window)speechSynthesis.cancel();$("#voiceStatus").textContent="Narración detenida.";});
$("#videoInfo").addEventListener("click",()=>toast("Para crear MP4 reales hay que conectar un proveedor de vídeo IA y un backend seguro."));
function safe(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function projectCard(p){
  const date=new Date(p.created).toLocaleDateString("es-ES");
  return `<article class="project-item"><div><h3>${safe(p.title)}</h3><small>${date} · ${p.cast.map(k=>emojis[k]||"").join(" ")} · ${p.duration} min</small></div><div class="project-buttons"><button class="secondary-button" data-open="${p.id}">Abrir guion</button><button class="danger-button" data-delete="${p.id}">Eliminar</button></div></article>`;
}
function renderProjects(){
  const recent=$("#recentProjects"),all=$("#allProjects");
  if(!projects.length){
    const empty='<div class="empty-state"><span>✦</span><b>Aún no hay proyectos guardados</b><small>Crea tu primera historia y guárdala para verla aquí.</small></div>';
    recent.innerHTML=empty;all.innerHTML=empty;return;
  }
  recent.innerHTML=projects.slice(0,3).map(projectCard).join("");
  all.innerHTML=projects.map(projectCard).join("");
}
document.addEventListener("click",e=>{
  const open=e.target.closest("[data-open]"),del=e.target.closest("[data-delete]");
  if(open){
    const p=projects.find(x=>x.id===Number(open.dataset.open));if(!p)return;
    currentStory=p.content;$("#storyTitle").textContent=p.title;$("#storyText").textContent=p.content;
    $("#storyResult").classList.remove("hidden");navigate("crear");$("#storyResult").scrollIntoView({behavior:"smooth"});
  }
  if(del){
    projects=projects.filter(x=>x.id!==Number(del.dataset.delete));persist();renderProjects();toast("Proyecto eliminado.");
  }
});
$("#exportProjects").addEventListener("click",()=>{
  const blob=new Blob([JSON.stringify(projects,null,2)],{type:"application/json"});
  const url=URL.createObjectURL(blob);const a=document.createElement("a");
  a.href=url;a.download="mis-proyectos-minimundo.json";a.click();URL.revokeObjectURL(url);
});
$("#clearProjects").addEventListener("click",()=>{
  if(!projects.length){toast("No hay proyectos que borrar.");return;}
  if(confirm("¿Seguro que quieres borrar todos tus proyectos guardados en este dispositivo?")){
    projects=[];persist();renderProjects();toast("Biblioteca vaciada.");
  }
});
renderProjects();
if("serviceWorker"in navigator && location.protocol!=="file:"){
  window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(err=>console.warn("PWA:",err)));
}

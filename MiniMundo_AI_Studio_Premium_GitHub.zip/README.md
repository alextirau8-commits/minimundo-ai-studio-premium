# MiniMundo AI Studio — Premium

Aplicación web instalable (PWA) con interfaz oscura futurista.

## Archivos
- `index.html`: estructura de la aplicación.
- `styles.css`: diseño responsive.
- `app.js`: navegación, creación de borradores de guion, voz del navegador y biblioteca local.
- `manifest.webmanifest` y `sw.js`: instalación y caché PWA.
- `icon.svg`: icono.

## Publicar en GitHub Pages
1. Sube todos los archivos a la raíz del repositorio.
2. En Settings → Pages selecciona Deploy from a branch.
3. Elige `main` y `/(root)` y guarda.
4. Espera a que aparezca Visit site.

## Funciones de esta versión
- Navegación entre secciones.
- Selección de Leo, Coco y Dumbo.
- Creación de un borrador de guion a partir de una idea.
- Lectura del guion con voces disponibles en el navegador.
- Guardado, apertura, borrado y exportación de proyectos en el almacenamiento local del dispositivo.
- Diseño adaptable a móvil y escritorio.

## Importante: funciones de IA reales
Esta versión no genera imágenes ni vídeos MP4 mediante IA. Tampoco usa un modelo de IA para escribir el guion: crea un borrador local a partir de una plantilla. Para esas funciones hace falta un backend alojado por separado y proveedores de IA con sus propias condiciones, límites y posibles costes. Las claves privadas nunca deben ponerse en el JavaScript público.
